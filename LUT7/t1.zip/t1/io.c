#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "io.h"

int lue_askeleet_listaan(int *lista, int len) {
        int summa = 0;
        char buffer[SIZE];
        FILE *pFile = NULL;
        int i = 0;
        printf("lue called\n");

        if (!(pFile = fopen("askeldata.txt","rt"))) {
                perror("askeldata.txt");
                exit(-1);
        }

        while (len > 0) {
                printf("for called\n");
                int counter = 0;
                fgets(buffer, SIZE, pFile);
                while (buffer[counter] != ':') {
                        counter++;
                }
                lista[i] = atoi(buffer + counter);
                summa += lista[i];
                printf("%d\n", lista[i]);
                i++;
                len--;
        }
        fclose(pFile);
        return summa;
}


void tulosta_lista(int *lista, int len) {
        int  i = 0;
        while(i < len) {
                printf("%d ", lista[i]);
                i++;
        }
        printf("\n");
}
