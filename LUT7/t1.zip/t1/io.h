#ifndef IO_H
#define IO_H
#define LEN 10
#define SIZE 1024

int lue_askeleet_listaan(int *, int);
void tulosta_lista(int *, int);

#endif /*IO_H*/
