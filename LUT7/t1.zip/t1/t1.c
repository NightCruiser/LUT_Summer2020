#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "io.h"

int main(int argc, char *argv[]) {
        int askList[LEN];
        int summa = 0;

        summa = lue_askeleet_listaan(askList, LEN);
        printf("Askelanalyysi\n"
               "Listan askeleet: ");
        tulosta_lista(askList, LEN);
        printf("Askelia yhteensä: %d\n", summa);
        return 0;
}
